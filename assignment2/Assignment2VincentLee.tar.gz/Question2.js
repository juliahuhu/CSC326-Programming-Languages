//Question 2a
function afunction(num){ 
	return !(num%2)|| !(num%3)
}
