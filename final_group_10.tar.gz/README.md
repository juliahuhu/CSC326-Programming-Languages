CSC326
======

To use the installation package:
Untar the tar ball using the following command:
%>tar -tzf installPackage.tar.gz

run the install.sh script with sudo permmission.
